(function () {
  "use strict";

  const queryInput = document.getElementById("query");
  const results = document.getElementById("results");
  const grid = document.getElementById("grid");
  const status = document.getElementById("status");
  const more = document.getElementById("more");
  const retry = document.getElementById("retry");
  let api;
  let query = "";
  let page = 0;
  let generation = 0;
  let loading = false;
  let inserting = false;
  let previewQueue = [];
  let previewActive = 0;

  function message(text, error = false) {
    status.textContent = text;
    status.dataset.error = String(error);
  }

  function theme(environment) {
    const colors = {keyboardContainer: "background", onKeyboardContainer: "foreground", surfaceContainerHighest: "surface", primary: "accent", error: "error"};
    for (const [key, variable] of Object.entries(colors)) {
      if (/^#[0-9a-f]{6}$/i.test(environment[key])) document.documentElement.style.setProperty("--" + variable, environment[key]);
    }
    document.documentElement.style.colorScheme = environment.dark ? "dark" : "light";
  }

  const observer = new IntersectionObserver(entries => {
    for (const entry of entries) {
      if (entry.isIntersecting) {
        observer.unobserve(entry.target);
        previewQueue.push(entry.target.previewTask);
      }
    }
    pumpPreviews();
  }, {root: results, rootMargin: "80px"});

  function pumpPreviews() {
    while (previewActive < 2 && previewQueue.length) {
      const task = previewQueue.shift();
      if (task.generation !== generation) continue;
      previewActive++;
      loadPreview(task).finally(() => { previewActive--; pumpPreviews(); });
    }
  }

  async function loadPreview(task) {
    try {
      const media = await api.download(task.url);
      if (task.generation !== generation || !task.button.isConnected) return;
      const image = document.createElement("img");
      image.alt = task.title;
      image.src = media.previewUrl;
      image.addEventListener("error", () => image.replaceWith(task.label));
      task.button.replaceChildren(image);
    } catch (_) {
      if (task.generation === generation) task.label.textContent = task.title + " · Tap to download";
    }
  }

  async function insert(item, button, itemQuery, itemGeneration) {
    if (inserting) return;
    const url = window.Klipy.rendition(item, ["md", "sm", "xs", "hd"]);
    if (!url) { message("This result has no supported GIF file.", true); return; }
    inserting = true;
    button.dataset.inserting = "true";
    button.disabled = true;
    message("Downloading GIF…");
    try {
      await window.wisp.ui.hideKeyboard();
      const media = await api.download(url);
      if (itemGeneration !== generation) return;
      try {
        await window.wisp.keyboard.insertMedia(media.handle, media.mimeType);
      } catch (_) {
        throw new Error("This app could not accept the GIF. Check media permission or try another app.");
      }
      message("GIF inserted.");
      // Only record successful insertions. Analytics failure must not block insertion.
      api.share(item.slug, itemQuery).catch(() => {});
    } catch (error) {
      if (itemGeneration === generation) message(error.message, true);
    } finally {
      inserting = false;
      button.disabled = false;
      delete button.dataset.inserting;
    }
  }

  function appendItem(item, itemGeneration, itemQuery) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "gif";
    const title = typeof item.title === "string" ? item.title : "GIF";
    button.setAttribute("aria-label", "Insert " + title);
    const label = document.createElement("span");
    label.className = "label";
    label.textContent = title;
    button.append(label);
    button.addEventListener("click", () => insert(item, button, itemQuery, itemGeneration));
    grid.append(button);
    const url = window.Klipy.rendition(item, ["xs", "sm", "md", "hd"]);
    if (url) {
      button.previewTask = {button, label, title, url, generation: itemGeneration};
      observer.observe(button);
    }
  }

  async function load(reset = false) {
    if (!api || (loading && !reset)) return;
    if (reset) {
      generation++;
      page = 0;
      query = queryInput.value.trim();
      observer.disconnect();
      previewQueue = [];
      grid.replaceChildren();
      results.scrollTop = 0;
    }
    const requestGeneration = generation;
    const requestedPage = page + 1;
    const requestedQuery = query;
    loading = true;
    more.hidden = true;
    retry.hidden = true;
    grid.setAttribute("aria-busy", "true");
    message(requestedQuery ? "Searching KLIPY…" : "Loading trending GIFs…");
    try {
      const response = await api.list(requestedQuery, requestedPage);
      if (requestGeneration !== generation) return;
      for (const item of response.items) appendItem(item, requestGeneration, requestedQuery);
      page = requestedPage;
      more.hidden = !response.hasNext;
      message(grid.childElementCount ? (requestedQuery ? "Results for “" + requestedQuery + "”" : "Trending on KLIPY") : "No GIFs found. Try a different search.");
    } catch (error) {
      if (requestGeneration !== generation) return;
      message(error.message, true);
      retry.hidden = false;
    } finally {
      if (requestGeneration === generation) {
        loading = false;
        grid.setAttribute("aria-busy", "false");
      }
    }
  }

  document.getElementById("search").addEventListener("submit", event => {
    event.preventDefault();
    load(true);
    if (window.wisp) window.wisp.ui.hideKeyboard().catch(() => {});
  });
  document.getElementById("trending").addEventListener("click", () => {
    queryInput.value = "";
    load(true);
    if (window.wisp) window.wisp.ui.hideKeyboard().catch(() => {});
  });
  queryInput.addEventListener("focus", () => {
    if (window.wisp) window.wisp.ui.showKeyboard().catch(() => message("Could not open the keyboard. Tap the search field again.", true));
  });
  more.addEventListener("click", () => load());
  retry.addEventListener("click", () => api ? load() : start());
  window.addEventListener("wisp:environment", event => theme(event.detail));

  let starting = false;
  async function start() {
    if (starting) return;
    starting = true;
    retry.hidden = true;
    try {
      // The native bridge is injected after onPageFinished, after deferred scripts run.
      for (let attempt = 0; !window.wisp && attempt < 200; attempt++) {
        await new Promise(resolve => setTimeout(resolve, 50));
      }
      if (!window.wisp) throw new Error("Open this GIF add-on inside Wisp Keyboard.");
      const bridge = window.wisp;
      theme(await bridge.ui.getEnvironment());
      let customerId = await bridge.storage.get("customerId");
      if (!customerId) {
        customerId = "wisp-" + Array.from(crypto.getRandomValues(new Uint8Array(16)), byte => byte.toString(16).padStart(2, "0")).join("");
        await bridge.storage.set("customerId", customerId);
      }
      const filter = await bridge.settings.get("contentFilter") || "high";
      const locale = (navigator.language.split(/[-_]/).slice(1).find(part => /^[a-z]{2}$/i.test(part)) || "us").toLowerCase();
      api = new window.Klipy.Api(bridge, window.KLIPY_API_KEY, customerId, filter, locale);
      await load(true);
    } catch (error) {
      message(error.message, true);
      retry.hidden = false;
    } finally {
      starting = false;
    }
  }
  start();
})();

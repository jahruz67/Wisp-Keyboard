(function () {
  "use strict";

  const queryInput = document.getElementById("query");
  const results = document.getElementById("results");
  const grid = document.getElementById("grid");
  const status = document.getElementById("status");
  const notice = document.getElementById("notice");
  const more = document.getElementById("more");
  const retry = document.getElementById("retry");
  const sessionId = "wisp-" + Date.now().toString(36) + "-" + Math.random().toString(36).slice(2) + Math.random().toString(36).slice(2);
  let api;
  let initialization;
  let query = "";
  let page = 0;
  let generation = 0;
  let loading = false;
  let inserting = false;
  let keyboardRequest;
  let previewQueue = [];
  let previewActive = 0;

  const sleep = milliseconds => new Promise(resolve => setTimeout(resolve, milliseconds));
  function replaceContents(element, child) {
    // Element.replaceChildren is absent in older Android System WebViews.
    while (element.firstChild) element.removeChild(element.firstChild);
    if (child) element.appendChild(child);
  }

  function message(text, error = false) {
    status.textContent = text;
    status.dataset.error = String(error);
  }

  function warning(text) {
    notice.textContent = text;
    notice.hidden = !text;
  }

  function theme(environment) {
    if (!environment) return;
    const colors = {keyboardContainer: "background", onKeyboardContainer: "foreground", surfaceContainerHighest: "surface", primary: "accent", error: "error"};
    for (const key of Object.keys(colors)) {
      if (/^#[0-9a-f]{6}$/i.test(environment[key])) document.documentElement.style.setProperty("--" + colors[key], environment[key]);
    }
    document.documentElement.style.colorScheme = environment.dark ? "dark" : "light";
  }

  function optional(call, fallback) {
    return new Promise(resolve => {
      const timeout = setTimeout(() => resolve(fallback), 1500);
      Promise.resolve().then(call).then(value => {
        clearTimeout(timeout);
        resolve(value == null ? fallback : value);
      }, () => { clearTimeout(timeout); resolve(fallback); });
    });
  }

  async function bridgeReady() {
    for (let attempt = 0; !window.wisp && attempt < 200; attempt++) await sleep(50);
    if (!window.wisp) throw new Error("Open this GIF add-on from Wisp's keyboard action menu.");
    return window.wisp;
  }

  async function initialize() {
    const bridge = await bridgeReady();
    if (!window.Klipy || !window.KLIPY_API_KEY) throw new Error("GIF add-on files did not load. Reinstall the ZIP.");
    // Theme and persisted preferences are optional; they must not disable GIF browsing.
    optional(() => bridge.ui.getEnvironment(), null).then(theme);
    const values = await Promise.all([
      optional(() => bridge.storage.get("customerId"), null),
      optional(() => bridge.settings.get("contentFilter"), "high")
    ]);
    const customerId = values[0] || sessionId;
    if (!values[0]) optional(() => bridge.storage.set("customerId", customerId), null);
    const filter = ["high", "medium", "low", "off"].indexOf(values[1]) >= 0 ? values[1] : "high";
    const locale = ((navigator.language || "en-US").split(/[-_]/).slice(1).find(part => /^[a-z]{2}$/i.test(part)) || "us").toLowerCase();
    api = new window.Klipy.Api(bridge, window.KLIPY_API_KEY, customerId, filter, locale);
    return api;
  }

  function ready() {
    if (!initialization) initialization = initialize().catch(error => { initialization = null; throw error; });
    return initialization;
  }

  const observer = typeof IntersectionObserver === "function" ? new IntersectionObserver(entries => {
    for (const entry of entries) {
      if (entry.isIntersecting) {
        observer.unobserve(entry.target);
        previewQueue.push(entry.target.previewTask);
      }
    }
    pumpPreviews();
  }, {root: results, rootMargin: "80px"}) : null;

  function pumpPreviews() {
    while (previewActive < 2 && previewQueue.length) {
      const task = previewQueue.shift();
      if (task.generation !== generation) continue;
      previewActive++;
      const complete = () => { previewActive--; pumpPreviews(); };
      loadPreview(task).then(complete, complete);
    }
  }

  async function loadPreview(task) {
    try {
      const media = await api.download(task.url);
      if (task.generation !== generation || !grid.contains(task.button)) return;
      const image = document.createElement("img");
      image.alt = task.title;
      image.addEventListener("error", () => replaceContents(task.button, task.label));
      image.src = media.previewUrl;
      replaceContents(task.button, image);
    } catch (error) {
      if (task.generation === generation) {
        task.label.textContent = task.title + " - Tap to download";
        warning(error.message);
      }
    }
  }

  async function hideKeyboard() {
    const bridge = await bridgeReady();
    await bridge.ui.hideKeyboard();
  }

  function requestKeyboard() {
    if (keyboardRequest) return keyboardRequest;
    keyboardRequest = (async () => {
      const bridge = await bridgeReady();
      let lastError;
      // DOM focus precedes Chromium's native editor notification. Reconnect on later taps too.
      for (const delay of [80, 120, 200, 300, 400]) {
        await sleep(delay);
        if (document.activeElement !== queryInput) return;
        try {
          await bridge.ui.showKeyboard();
          warning("");
          return;
        } catch (error) {
          lastError = error;
          if (!/no editable|focused|input connection/i.test(error.message || "")) break;
        }
      }
      if (document.activeElement === queryInput) warning("Keyboard: " + (lastError && lastError.message || "Could not connect the search field."));
    })().catch(error => warning("Keyboard: " + error.message)).then(() => { keyboardRequest = null; });
    return keyboardRequest;
  }

  async function insert(item, button, itemQuery, itemGeneration) {
    if (inserting) return;
    const url = window.Klipy.rendition(item, ["md", "sm", "xs", "hd"]);
    if (!url) { warning("This result has no supported GIF file."); return; }
    inserting = true;
    button.dataset.inserting = "true";
    button.disabled = true;
    message("Downloading GIF...");
    try {
      await hideKeyboard();
      const media = await api.download(url);
      if (itemGeneration !== generation) return;
      try {
        await window.wisp.keyboard.insertMedia(media.handle, media.mimeType);
      } catch (error) {
        throw new Error("This app could not accept the GIF. " + error.message);
      }
      if (itemGeneration === generation) { warning(""); message("GIF inserted."); }
      api.share(item.slug, itemQuery).catch(() => {});
    } catch (error) {
      if (itemGeneration === generation) message(error.message, true);
    } finally {
      inserting = false;
      button.disabled = false;
      delete button.dataset.inserting;
    }
  }

  function appendItem(item, itemGeneration, itemQuery) {
    const button = document.createElement("button");
    button.type = "button";
    button.className = "gif";
    const title = typeof item.title === "string" ? item.title : "GIF";
    button.setAttribute("aria-label", "Insert " + title);
    const label = document.createElement("span");
    label.className = "label";
    label.textContent = title;
    button.appendChild(label);
    button.addEventListener("click", () => insert(item, button, itemQuery, itemGeneration));
    grid.appendChild(button);
    const url = window.Klipy.rendition(item, ["xs", "sm", "md", "hd"]);
    if (url) {
      button.previewTask = {button, label, title, url, generation: itemGeneration};
      // Load the first two rows immediately. Native WebView resizes can delay
      // IntersectionObserver notifications even though results have arrived.
      if (observer && grid.childElementCount > 6) observer.observe(button);
      else previewQueue.push(button.previewTask);
    }
  }

  async function load(reset = false) {
    if (loading && !reset) return;
    if (reset) {
      generation++;
      page = 0;
      query = queryInput.value.trim();
      if (observer) observer.disconnect();
      previewQueue = [];
      replaceContents(grid);
      results.scrollTop = 0;
      warning("");
    }
    const requestGeneration = generation;
    const requestedPage = page + 1;
    const requestedQuery = query;
    loading = true;
    more.hidden = true;
    retry.hidden = true;
    grid.setAttribute("aria-busy", "true");
    message(requestedQuery ? "Searching KLIPY..." : "Loading trending GIFs...");
    try {
      await ready();
      if (requestGeneration !== generation) return;
      const response = await api.list(requestedQuery, requestedPage);
      if (requestGeneration !== generation) return;
      for (const item of response.items) appendItem(item, requestGeneration, requestedQuery);
      pumpPreviews();
      page = requestedPage;
      more.hidden = !response.hasNext;
      message(grid.childElementCount ? (requestedQuery ? "Results for " + requestedQuery : "Trending on KLIPY") : "No GIFs found. Try a different search.");
    } catch (error) {
      if (requestGeneration !== generation) return;
      message(error.message, true);
      retry.hidden = false;
    } finally {
      if (requestGeneration === generation) {
        loading = false;
        grid.setAttribute("aria-busy", "false");
      }
    }
  }

  document.getElementById("search").addEventListener("submit", event => {
    event.preventDefault();
    load(true);
    hideKeyboard().catch(error => warning("Keyboard: " + error.message));
  });
  document.getElementById("trending").addEventListener("click", () => {
    queryInput.value = "";
    load(true);
    hideKeyboard().catch(error => warning("Keyboard: " + error.message));
  });
  queryInput.addEventListener("focus", requestKeyboard);
  queryInput.addEventListener("click", requestKeyboard);
  more.addEventListener("click", () => load());
  retry.addEventListener("click", () => load());
  window.addEventListener("wisp:environment", event => theme(event.detail));
  load(true);
})();

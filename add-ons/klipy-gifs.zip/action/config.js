// Public client application key, intentionally bundled for setup-free GIF search.
window.KLIPY_API_KEY = "JCdXovbaQz89rehrSQR1cThyCkzINOxNuWqVp8GZvsYrjdFUlX1MGReXuoQFkumF";

(function () {
  "use strict";

  const mediaOrigins = new Set([
    "https://static.klipy.com", "https://static1.klipy.com", "https://static2.klipy.com"
  ]);

  function mediaUrl(value) {
    if (typeof value !== "string") return null;
    try {
      const url = new URL(value);
      return mediaOrigins.has(url.origin) && !url.username && !url.password ? url.href : null;
    } catch (_) {
      return null;
    }
  }

  function rendition(item, sizes) {
    for (const size of sizes) {
      const file = item.file && item.file[size] && item.file[size].gif;
      const url = file && mediaUrl(file.url);
      if (url && (!file.size || file.size <= 25 * 1024 * 1024)) return url;
    }
    return null;
  }

  class KlipyApi {
    constructor(bridge, key, customerId, contentFilter, locale) {
      this.bridge = bridge;
      this.base = "https://api.klipy.com/api/v1/" + encodeURIComponent(key) + "/gifs/";
      this.customerId = customerId;
      this.contentFilter = contentFilter;
      this.locale = locale;
    }

    async request(path, parameters, body) {
      const url = this.base + path + (parameters ? "?" + new URLSearchParams(parameters) : "");
      let response;
      try {
        response = await this.bridge.network.fetch({
          url,
          method: body ? "POST" : "GET",
          headers: body ? {"Content-Type": "application/json", Accept: "application/json"} : {Accept: "application/json"},
          ...(body ? {body: JSON.stringify(body)} : {})
        });
      } catch (_) {
        // Bridge/network errors can contain the request URL, including the client key.
        throw new Error("Could not connect to KLIPY. Check your connection and network permission, then try again.");
      }
      if (response.status === 429) throw new Error("KLIPY is busy. Please wait a moment and try again.");
      if (response.status === 401 || response.status === 403) throw new Error("KLIPY could not authorize GIF search. Please try again later.");
      if (response.status < 200 || response.status >= 300) throw new Error("KLIPY could not load GIFs. Please try again.");
      let result;
      try { result = JSON.parse(response.body); } catch (_) {
        throw new Error("KLIPY returned an unreadable response. Please try again.");
      }
      if (!result || result.result !== true) throw new Error("KLIPY could not complete the request. Please try again.");
      return result.data;
    }

    async list(query, page) {
      const parameters = {
        page: String(page), per_page: "24", customer_id: this.customerId,
        locale: this.locale, content_filter: this.contentFilter, format_filter: "gif"
      };
      if (query) parameters.q = query;
      const data = await this.request(query ? "search" : "trending", parameters);
      if (!data || !Array.isArray(data.data)) throw new Error("KLIPY returned unexpected results. Please try again.");
      return {items: data.data, hasNext: data.has_next === true};
    }

    async download(url) {
      if (!mediaUrl(url)) throw new Error("This GIF has an unsupported media address.");
      let media;
      try { media = await this.bridge.network.fetch({url, responseType: "media"}); } catch (_) {
        throw new Error("Could not download this GIF. Check your connection and media permission, then try again.");
      }
      if (media.status < 200 || media.status >= 300 || media.mimeType !== "image/gif" || !media.handle) {
        throw new Error("This GIF could not be downloaded. Please try another GIF.");
      }
      return media;
    }

    share(slug, query) {
      if (!slug) return Promise.resolve();
      return this.request("share/" + encodeURIComponent(slug), null, {customer_id: this.customerId, q: query});
    }
  }

  window.Klipy = {Api: KlipyApi, rendition};
})();
